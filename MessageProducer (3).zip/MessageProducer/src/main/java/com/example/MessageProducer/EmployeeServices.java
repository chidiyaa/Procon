package com.example.MessageProducer;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/emp")
public class EmployeeServices {
	@Autowired
	EmployeeDAO employeeDao;
	
	ArrayList<Employee> empList=new ArrayList<Employee>();
	
	@GetMapping(value="/select/{id}",produces=MediaType.APPLICATION_XML_VALUE)	
	
	public Employee readEmployee(@PathVariable("id")Long id)
	{
		//Employee emp1=new Employee();
		/*Employee emp=new Employee();
		emp.setAge(12);
		emp.setName("ABC");
		emp.setSalary(1234);
		System.out.println(id);
		return emp;*/
		
		return employeeDao.getOne(id);
	}
		@GetMapping(value="/retrieveall")
		public List<Employee> retrieveAll()
		{
			return employeeDao.findAll();
		}
		@GetMapping(value="/deleteid/{id}",produces=MediaType.APPLICATION_JSON_VALUE)
		public void deleteById(@PathVariable("id")Long id)
		{
			employeeDao.deleteById(id);
		}
		@PutMapping(value="/update/{id}",consumes=MediaType.APPLICATION_JSON_VALUE)
		public Employee updateEmployee(@PathVariable("id")Long id)
		{
			Optional<Employee> em=employeeDao.findById(id);
			
			if(em.isPresent())
			{
				Employee employee=new Employee();
				employee=employeeDao.getOne(id);
				System.out.println(employee);
				employee.setAge(25);
				employeeDao.save(employee);
				System.out.println(employee);
				return employee;
			}
			else
				return null;
			
			
		}
	@PostMapping(value="/insert",consumes=MediaType.APPLICATION_JSON_VALUE)
	public Employee insertEmployee(@RequestBody Employee emp1)
	{
		employeeDao.save(emp1);
		return emp1;
	}
	@PostMapping(value="/insertMultiple",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ArrayList<Employee> insertEmployee(@RequestBody ArrayList<Employee> employeeList)
	{
		empList=employeeList;
		employeeDao.saveAll(employeeList);
		return empList;
	}

}
